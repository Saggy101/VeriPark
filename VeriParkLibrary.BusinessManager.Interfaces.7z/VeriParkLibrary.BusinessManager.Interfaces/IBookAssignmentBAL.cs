﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VeriParkLibrary.Entities;

namespace VeriParkLibrary.BusinessManager.Interfaces
{
    public interface IBookAssignmentBAL
    {
        int AssignBooks(string personId, string bookId, DateTime assignedDate, string status);
        Person getPersonDetails(string personId);
        BookRecord getBookDetails(string bookId);
        IEnumerable<BoogAssignmentDetails> getAllBookAssignments();
        BookAssign getSpecificBookAssigned(string assignedid);
        IEnumerable<Person> getAllPersons();
        int ReturnBooks(BookAssign bookCheckinModel);
    }
}
