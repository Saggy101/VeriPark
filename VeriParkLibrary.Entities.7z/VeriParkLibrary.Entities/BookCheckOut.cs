﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriParkLibrary.Entities
{
    public class BookCheckOut
    {
        public string bookid { get; set; }
        public string bookname { get; set; }
        public string bookISBN { get; set; }
        public string bookpubname { get; set; }
        public string bookpubyear { get; set; }
        public string bookprice { get; set; }
        public string personid { get; set; }
        public string personname { get; set; }
        public string mobilenumber { get; set; }
    }
}
