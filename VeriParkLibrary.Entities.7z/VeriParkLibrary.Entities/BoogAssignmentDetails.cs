﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriParkLibrary.Entities
{
    public class BoogAssignmentDetails
    {
        public string assignmentId { get; set; }
        public string personId { get; set; }
        public string bookId { get; set; }
        public string bookname { get; set; }
        public string ISBM { get; set; }
        public string coverprice { get; set; }
        public string status { get; set; }
    }
}
