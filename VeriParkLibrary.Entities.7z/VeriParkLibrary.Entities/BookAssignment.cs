﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriParkLibrary.Entities
{
    public class BookAssignment
    {
        public string personId { get; set; }
        public string bookId { get; set; }
        public string assignedDate { get; set; }
        public string returnDate { get; set; }
        public string penalty { get; set; }
        public string statusid { get; set; }
        public string updatedstatusdate { get; set; }
    }
}
