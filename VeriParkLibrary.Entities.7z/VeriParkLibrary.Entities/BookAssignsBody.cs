﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriParkLibrary.Entities
{
    public class BookAssignsBody
    {
       // public int id { get; set; }
        public string assignid { get; set; }
        public string personid { get; set; }
        public string bookid { get; set; }
        public string bookname { get; set; }
        public string assigneddate { get; set; }
        public string returndate { get; set; }
        public string coverprice { get; set; }
        public string ISBM { get; set; }
        //public string status { get; set; }
        public string penality { get; set; }
        public string statusid { get; set; }
        public string updatestatusdate { get; set; }
    }
}
