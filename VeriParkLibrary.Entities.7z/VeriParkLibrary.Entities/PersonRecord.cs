﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriParkLibrary.Entities
{
    public class PersonRecord
    {
        public int id { get; set; }
        public string personid { get; set; }
        public string personname { get; set; }
        public string nationalid { get; set; }
        public string mobilenumber { get; set; }
    }
}
