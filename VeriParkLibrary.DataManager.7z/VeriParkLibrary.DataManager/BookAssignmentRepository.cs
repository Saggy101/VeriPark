﻿using LinqKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using VeriParkLibrary.Entities;
using VeriParkLibrary.Entities.Interfaces;


namespace VeriParkLibrary.DataManager
{
    public class BookAssignmentRepository : IBookAssignmentRepository
    {
        //initialize logging 
        public static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public int AssignBooks(BookAssignment objBookAssign)
        {
            BookAssign _objAssign = new BookAssign();
            using (LibraryVeriparkEntities dbEntity = new LibraryVeriparkEntities())
            {
                dbEntity.Database.Connection.Open();
                var prev = dbEntity.BookAssigns.Where(a => a.personid == objBookAssign.personId && a.bookid == objBookAssign.bookId).FirstOrDefault();
                if (prev == null)
                {
                    _objAssign.bookid = objBookAssign.bookId.ToString();
                    _objAssign.personid = objBookAssign.personId.ToString();
                    _objAssign.assigneddate = objBookAssign.assignedDate;
                    _objAssign.statusid = "std2";
                    string returndate = DateTime.Today.AddDays(15).ToShortDateString();
                    _objAssign.returndate = returndate;
                    _objAssign.penality = objBookAssign.penalty;
                    _objAssign.updatestatusdate = objBookAssign.updatedstatusdate;

                    dbEntity.BookAssigns.Add(_objAssign);
                    dbEntity.SaveChanges();
                }
                else
                {
                    return -1;
                }
                //dbEntity.Database.Connection.Close();
            }
            return 0;
        }

        public BookAssign getSpecificBookAssigned(string assignedid)
        {
            BookAssign objAssigned = new BookAssign();
            using (LibraryVeriparkEntities dbEntity = new LibraryVeriparkEntities())
            {
                dbEntity.Database.Connection.Open();
                var obj = dbEntity.BookAssigns.Where(a => a.assignid == assignedid).FirstOrDefault();
                if(obj != null)
                {
                    objAssigned = obj;
                }
            }
            return objAssigned;
        }

        public int ReturnBooks(BookAssign bookCheckinModel)
        {
            BookAssign _objAssign = new BookAssign();
            using (LibraryVeriparkEntities dbEntity = new LibraryVeriparkEntities())
            {
                dbEntity.Database.Connection.Open();
                var objResult = dbEntity.BookAssigns.Where(a => a.assignid == bookCheckinModel.assignid).FirstOrDefault();
                if (objResult != null)
                {
                    dbEntity.BookAssigns.Remove(objResult);
                    dbEntity.SaveChanges();
                    return 1;
                }
                else
                {
                    return -1;
                }
            }
        }

        public IEnumerable<Person> getAllPersons()
        {
            IEnumerable<Person> objPerson = null;
            LibraryVeriparkEntities dbEntity = new LibraryVeriparkEntities();
            dbEntity.Database.Connection.Open();
            objPerson = dbEntity.People.AsEnumerable<Person>();
                
            return objPerson.AsEnumerable();

        }

        public  IEnumerable<BoogAssignmentDetails> getAssignedBooks()
        {
            IEnumerable<BoogAssignmentDetails> _objAssignments = null;
            LibraryVeriparkEntities dbEntity = new LibraryVeriparkEntities();
            //{
                dbEntity.Database.Connection.Open();

            //var obj = dbEntity.BookRecords.LeftOuterJoin2(dbEntity.BookAssigns, x => x.bookid, y => y.bookid, (x, y) => new { x, y });

            var q1 = Queryable.GroupJoin(dbEntity.BookRecords, dbEntity.BookAssigns, a => a.bookid, b => b.bookid, (a, b) => new { a, groupB = b.DefaultIfEmpty() });
            var q2 = Queryable.SelectMany(q1, x => x.groupB, (a, b) =>new { a.a, b });
            var q3 = Queryable.SelectMany(dbEntity.BookRecords, a => q2.Where(x => x.a == a).Select(x => x.b), (a, b) => new { a, b });

            var q4 = Queryable.GroupJoin(q3, dbEntity.statusdetails, x => x.b.statusid, y => y.statusid, (x, y) => new { x, groupC = y.DefaultIfEmpty() });

            var q5 = Queryable.SelectMany(q4, f => f.groupC, (p, m) => new { p.x, m });

            var q6 = Queryable.Select(q5, x => new BoogAssignmentDetails { assignmentId = x.x.b.assignid, bookId = x.x.a.bookid, bookname = x.x.a.bookname, coverprice = x.x.a.bookprice, ISBM = x.x.a.bookISBN, personId = x.x.b.personid, status = x.m.statusname });

                //var obj = (from x in dbEntity.BookRecords
                //           join y in dbEntity.BookAssigns on x.bookid equals y.bookid into ps
                //           from y in ps.DefaultIfEmpty()
                //           select new BookAssignsBody { assignid = y.assignid, bookid = x.bookid, bookname = x.bookid, personid = y.personid, coverprice = string.Empty, ISBM = x.bookISBN, statusid = y.statusid }
                //           ).DefaultIfEmpty();

                //var result = (from x in obj.DefaultIfEmpty()
                //              join y in dbEntity.statusdetails on x.statusid equals y.statusid
                //               select new BoogAssignmentDetails  { assignmentId =  (string.IsNullOrEmpty(x.assignid) ? "" : x.assignid), personId= (string.IsNullOrEmpty(x.personid)? "" : x.personid), bookId= y.id, bookname= x.bookname, ISBM= x.ISBM, coverprice= x.coverprice, status= (string.IsNullOrEmpty(y.statusname)? "" : y.statusname) });
                _objAssignments = q6.AsEnumerable();

            //dbEntity.Database.Connection.Close();
            //}
            return _objAssignments;
            //throw new NotImplementedException();
        }



     

            public BookRecord getBookRecords(string bookId)
        {
            BookRecord objBookRecord = new BookRecord();
            using (LibraryVeriparkEntities dbEntity = new LibraryVeriparkEntities())
            {
                dbEntity.Database.Connection.Open();
                objBookRecord = dbEntity.BookRecords.Where(a => a.bookid == bookId).FirstOrDefault();
                dbEntity.Database.Connection.Close();
            }
            return objBookRecord;
            //throw new NotImplementedException();
        }

        public Person getPersonDetails(string personId)
        {
            Person objPerson = new Person();
            using (LibraryVeriparkEntities dbEntity = new LibraryVeriparkEntities())
            {
                dbEntity.Database.Connection.Open();
                objPerson = dbEntity.People.Where(a => a.personid == personId).FirstOrDefault();
               // dbEntity.Database.Connection.Close();
            }
            return objPerson;
        }     //throw new NotImplementedException();
    }
}
