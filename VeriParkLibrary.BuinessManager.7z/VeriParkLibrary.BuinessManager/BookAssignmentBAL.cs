﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VeriParkLibrary.Entities;
using VeriParkLibrary.Entities.Interfaces;
using VeriParkLibrary.BusinessManager.Interfaces;

using System.Reflection;
using VeriParkLibrary.DataManager;

namespace VeriParkLibrary.BuinessManager
{
    public class BookAssignmentBAL : IBookAssignmentBAL
    {
        //initialize logging 
        public static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private readonly IBookAssignmentRepository _bookRepository;


       //COnstructor
       public BookAssignmentBAL(IBookAssignmentRepository repositroy)
        {
            this._bookRepository = repositroy;
        }
        public BookAssignmentBAL()
        {
            _bookRepository = new BookAssignmentRepository();
        }


        public int AssignBooks(string personId, string bookId, DateTime assignedDate, string status)
        {
            int result = 0;
            try
            {
                log.Info("Starts");
                BookAssignment objBookAssinment = new BookAssignment();
                objBookAssinment.personId = personId;
                objBookAssinment.bookId = bookId;
                objBookAssinment.assignedDate = assignedDate.ToString("MM-dd-yyyy");
                objBookAssinment.statusid = status;

                result = _bookRepository.AssignBooks(objBookAssinment);

                log.Info("Ends");
            }
            catch(Exception ex)
            {
                log.Error("Method Parameters - " + MethodBase.GetCurrentMethod().GetParameters(), ex);
                throw ex;
            }
            return result;
        }

        public int ReturnBooks(BookAssign bookCheckinModel)
        {
            int nResult = 0;
            try
            {
                log.Info("Starts");
               
                nResult = _bookRepository.ReturnBooks(bookCheckinModel);

                log.Info("Ends");
            }
            catch (Exception ex)
            {
                log.Error("Method Parameters - " + MethodBase.GetCurrentMethod().GetParameters(), ex);
                throw ex;
            }
            return nResult;
        }

        public BookAssign getSpecificBookAssigned(string assignedid)
        {
            BookAssign objAssignment = new BookAssign();
            try
            {
                log.Info("Starts");

                objAssignment = _bookRepository.getSpecificBookAssigned(assignedid);


                log.Info("Ends");
            }
            catch (Exception ex)
            {
                log.Error("Method Parameters - " + MethodBase.GetCurrentMethod().GetParameters(), ex);
                throw ex;
            }
            return objAssignment;
        }

        public IEnumerable<Person> getAllPersons()
        {
            IEnumerable<Person> objAllPersons = null;
            try
            {
                log.Info("Starts");
                objAllPersons = _bookRepository.getAllPersons();
                log.Info("Ends");

            }
            catch (Exception ex)
            {
                log.Error("Method Parameters - " + MethodBase.GetCurrentMethod().GetParameters(), ex);
                throw ex;
            }
            return objAllPersons;
        }



        public IEnumerable<BoogAssignmentDetails> getAllBookAssignments()
        {
            IEnumerable<BoogAssignmentDetails> objAssign = null;
            try
            {
                log.Info("Starts");

                objAssign = _bookRepository.getAssignedBooks();

                log.Info("Ends");
            }
            catch(Exception ex)
            {
                log.Error("Method Parameters - " + MethodBase.GetCurrentMethod().GetParameters(), ex);
                throw ex;
            }
            return objAssign;
        }

        public Entities.BookRecord getBookDetails(string bookId)
        {
            BookRecord objBookRecord = new BookRecord();
            try
            {
                log.Info("Starts");

                objBookRecord = _bookRepository.getBookRecords(bookId);
            }
            catch(Exception ex)
            {
                log.Error("Method Parameters - " + MethodBase.GetCurrentMethod().GetParameters(), ex);
                throw ex;
            }
            //throw new NotImplementedException();
            return objBookRecord;
        }

        public Entities.Person getPersonDetails(string personId)
        {
            Person objPerson = new Person();
            try
            {
                log.Info("Starts");

                objPerson = _bookRepository.getPersonDetails(personId);
            }
            catch(Exception ex)
            {
                log.Error("Method Parameters - " + MethodBase.GetCurrentMethod().GetParameters(), ex);
                throw ex;
            }
            //throw new NotImplementedException();
            return objPerson;
        }
    }
}
