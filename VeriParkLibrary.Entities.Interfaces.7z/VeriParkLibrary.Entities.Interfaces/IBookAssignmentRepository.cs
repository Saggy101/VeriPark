﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VeriParkLibrary.Entities;

namespace VeriParkLibrary.Entities.Interfaces
{
    public interface IBookAssignmentRepository
    {
        BookRecord getBookRecords(string bookId);
        Person getPersonDetails(string personId);
        IEnumerable<BoogAssignmentDetails> getAssignedBooks();
        BookAssign getSpecificBookAssigned(string assignedid);
        int AssignBooks(BookAssignment objBookAssign);
        IEnumerable<Person> getAllPersons();
        int ReturnBooks(BookAssign objBookAssign);
    }
}
